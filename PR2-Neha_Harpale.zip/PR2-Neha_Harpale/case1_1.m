clc,clear
close all
workspace;
flag=1;
if flag==1
    pos(1,:) = randperm(10,8);
    pos(2,:) = randperm(10,8);
    save('position.mat','pos');
else if flag==2
        load('position.mat','pos');
    end
end
cell_pos=[2,2];
comm_range = 2;
cv=0.01;
x_pos=0+4*rand([10,1]);
y_pos= 0 + 4*rand([10,1]);
init_position= [x_pos,y_pos];
r=5;
[matrix,index] = neighbors(10,init_position,r);
nodes = nodes_cal(index);
rs=5;
n=10;
Nodes = 1:10;
%ni=Nodes-1;
% noise 
% noise = 10;
% measure = 50 + randn(Nodes,1).*V;
ni=zeros(10,1); %%number of neighbors for each node
for j = Nodes
     ind1 = index(1,:)== j;           
     i1 = index(2,ind1);
     ni(j)=numel(i1);
   
end
%-Calculate neighbors of node--%
degree = zeros(10,1);
[sensor_neighbors,degree] = computeNeighbors(Nodes,init_position,r); 

 F=50;
 a = zeros(1,2);
  for j=Nodes
    a = sum (init_position); 
  end
 
qbar = (1/10) * [a];
nodes_va = 50.*ones(1,10)+ 1*randn(1,10);
nodes_va0 = nodes_va; %save the initial measurement
nodes_va_old = nodes_va; %to update the consensus
nodes_va1 = nodes_va;
nodes_va2 = nodes_va;

figure(1)
 draw_figure(init_position,index);
% for j=1:Nodes
 %    for k=1:Nodes
 %      init_position = theta+V{i,j};
  %   end
 %end
 iterations = 1000;
 Con = [];

%  average weighted consensus - weight 1 %

 O=zeros(2,10);
 i2 = []; %%observable nodes
 for node = Nodes
            if norm(init_position(node,:)-cell_pos,2) <= rs
                O(1,node)=node;
                O(2,node)= 1;
            else
                O(1,node)=node;
            end
 end
 for j=Nodes
     if O(2,j) == 1
         i2(end+1) = O(1,j); %% matrix [i2]
     end
 end
%% i2=i2bar';
 W=[];
 [W] =computeWeight1(cv,rs,i2,sensor_neighbors,nodes_va0);


 %---------call for consensus--------%
 [weight_matrix]=nodes_va0;
 converged = false;
 l = 1;
 while ~converged && l < 40000
            l = l+1;
            % Find converged sensor weight
            [nodes_va,converged] = computeWeightConsensus(i2,nodes_va,W,sensor_neighbors);
            weight_matrix=[weight_matrix;nodes_va];
 end
 
 figure(2)
 plot(Nodes,nodes_va,'-o',Nodes,nodes_va0,'-o');
 hold on;
 
 figure(3)
for i=1:10
 plot(weight_matrix(:,i));
 xlim([1 16000]);
 hold on;
 end

Weight=[];
[Weight] =computeWeight2(cv,rs,i2,sensor_neighbors,nodes_va0);


 %---------call for consensus--------%
 
 [weight_mat]=nodes_va0;
 converged = false;
 s = 1;
        while ~converged && s < iterations
            s = s+1;
            % Find converged sensor weight
            [nodes_va_old,converged] = computeWeightConsensus(i2,nodes_va_old,Weight,sensor_neighbors);
            weight_mat=[weight_mat;nodes_va_old];
        end
 
 figure(4)
plot(Nodes,nodes_va_old,'-o',Nodes,nodes_va0,'-o');
hold on

figure(5)
for i=1:10
 plot(weight_mat(:,i));
 xlim([1 10]);
 hold on;
 end
 

 
 
 
  [weight_matrix2]=nodes_va0;
 W1=[];
 [W1] =computeMaximumdegreeWeight(i2,sensor_neighbors,n);


 %---------call for consensus--------%
 converged = false;
 s1 = 0;
        while ~converged && s1 < iterations
            s1 = s1+1;
            % Find converged sensor weight
            [nodes_va1,converged] = computeWeightConsensus(i2,nodes_va1,W1,sensor_neighbors);
            weight_matrix2=[weight_matrix2;nodes_va1];
        end
 
 figure(6)
 plot(Nodes,nodes_va,'-o',Nodes,nodes_va0,'-o');
 hold on;
 
 figure(7)
for i=1:10
 plot(weight_matrix2(:,i));
 xlim([1 10]);
 hold on;
 end



[W2] =computeMetropolisWeight(i2,sensor_neighbors);


 %---------call for consensus--------%
 [weight_matrix3]=nodes_va2;
 converged = false;
 l1 = 0;
        while ~converged && l1 < iterations
            l1 = l1+1;
            % Find converged sensor weight
            [nodes_va2,converged] = computeWeightConsensus(i2,nodes_va2,W2,sensor_neighbors);
            weight_matrix3=[weight_matrix3;nodes_va2];
        end
 Weight2 = W;
 figure(8)
plot(Nodes,nodes_va_old,'-o',Nodes,nodes_va0,'-o');
hold on
 
 
 figure(9)
for i=1:10
 plot(weight_matrix3(:,i));
 xlim([1 10]);
 hold on;
 end
 
 
 
[m,n]=size(index); %%index matrix having node and its neighbors
nu=1:n;
[max_node,index_max]=max(ni);
max_neighbors=[];
for i=index_max
    for j=nu
     if index(1,j)==i
       max_neighbors(end+1)=index(2,j); 
     end
    end
     max_neighbors(end+1)=index_max;
end

[min_node,index_min]=min(ni(ni>0));
min_neighbors=[];
for i=index_min
    for j=nu
     if index(1,j)==i
       min_neighbors(end+1)=index(2,j); 
     end
    end
     min_neighbors(end+1)=index_min;
end

figure(10)
 for i=max_neighbors
 plot(weight_matrix2(:,i));
 xlim([1 10]);
 hold on;
 end

figure(11)
 for j=min_neighbors
 plot(weight_matrix2(:,j));
 xlim=([1 10]);
 hold on;
 end
 
 
 
 
 
 
 
 