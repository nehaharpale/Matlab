function [W] = computeMaximumdegreeWeight(i2,sensor_neighbors,n)
    for obs_node = i2
        obs_neighbors = intersect(i2,sensor_neighbors{obs_node});
        for j = obs_neighbors
            W(obs_node,j) = (1/n);
        end
        W(obs_node,obs_node) = 1 - (size(sensor_neighbors{obs_node},2)/n);
    end
end
 