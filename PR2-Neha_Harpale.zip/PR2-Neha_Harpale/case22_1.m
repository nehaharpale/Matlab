clc,clear
close all
workspace;
flag=1;
if flag==1
    pos(1,:) = randperm(30,25);
    pos(2,:) = randperm(30,25);
    save('position.mat','pos');
else if flag==2
        load('position.mat','pos');
    end
end
%cell_pos=[2,2];
cv=0.01;
x_pos=0+25*rand([30,1]);
y_pos= 0 + 25*rand([30,1]);
init_position= [x_pos,y_pos];
r=10;
[matrix,index] = neighbors(30,init_position,r);
nodes = nodes_cal(index);
rs=5;

Nodes = 1:30;
%ni=Nodes-1;
% noise 
% noise = 10;
% measure = 50 + randn(Nodes,1).*V;
ni=zeros(30,1); %%number of neighbors for each node
for j = Nodes
     ind1 = index(1,:)== j;           
     i1 = index(2,ind1);
     ni(j)=numel(i1);
   
end
%-Calculate neighbors of node--%
degree = zeros(30,1);
[sensor_neighbors,degree] = computeNeighbors(Nodes,init_position,r); 

 a = zeros(1,2);
  for j=Nodes
    a = sum (init_position); 
  end
 
qbar = (1/30) * [a];
nodes_va = 50.*ones(1,30)+ 1*randn(1,30);
nodes_va0 = nodes_va; %save the initial measurement
nodes_va_old = nodes_va; %to update the consensus

figure(1)
 draw_figure2(init_position,index);
% for j=1:Nodes
 %    for k=1:Nodes
 %      init_position = theta+V{i,j};
  %   end
 %end
 iterations = 1000;
 Con = [];
 n=30;
%  average weighted consensus - weight 1 

 

%  for i=x_cell
%      for j=y_cell
     
%      end
%  end
%  cell_pos=[x_cell,y_cell];

 O=zeros(2,30);
 i2 = []; %%observable nodes
 for node = Nodes
            if norm(init_position(node,:)-cell_pos,2) <= rs  %%while taking output remove cell dimensions
                O(1,node)=node;
            
                
                O(2,node)= 1;
            else
                O(1,node)=node;
            end
 end
 for j=Nodes
     if O(2,j) == 1
         i2(end+1) = O(1,j); %% matrix [i2]
     end
 end
 
 
