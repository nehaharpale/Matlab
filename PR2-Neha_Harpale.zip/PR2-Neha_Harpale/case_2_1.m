clc,clear
close all
workspace;
flag=1;
if flag==1
    pos(1,:) = randperm(30,25);
    pos(2,:) = randperm(30,25);
    save('position.mat','pos');
else if flag==2
        load('position.mat','pos');
    end
end

cv=0.01;
x_pos=0+25*rand([30,1]);
y_pos= 0 + 25*rand([30,1]);

init_position= [x_pos,y_pos];
r=25;
[matrix,index] = neighbors(30,init_position,r);
nodes = nodes_cal(index);
rs=5;
%nodes_va = 1.*ones(1,30)+ 1*randn(1,30);
%nodes_va0=nodes_va;
Nodes = 1:30;
ni=zeros(30,1); %%number of neighbors for each node
for j = Nodes
     ind1 = index(1,:)== j;           
     i1 = index(2,ind1);
     ni(j)=numel(i1);
end

figure(1)
 draw_figure2(init_position,index);