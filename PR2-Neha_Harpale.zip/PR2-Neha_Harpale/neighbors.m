
function [El,idx] = neighbors(N,pos,r)

m = N*(N-1)/2;

idx = zeros(2,m);
stp = 0;

for i = 1 : N
    for j = i+1 : N

        if norm( pos(i,:) - pos(j,:), 2 ) <= r
            stp = stp + 1;
            idx(:,stp) = [i j]';
        end
    end
end

idx = idx(:,1:stp);

El = sparse(incmat(idx,N));


