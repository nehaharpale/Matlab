function [W] = computeMetropolisWeight(i2,sensor_neighbors)
    for obs_node = i2
        obs_neighbors = intersect(i2,sensor_neighbors{obs_node});
        for j = obs_neighbors
            W(obs_node,j) = 1 / (1 + max(size(obs_neighbors,2),size(intersect(i2,sensor_neighbors{j}),2)));
        end
        W(obs_node,obs_node) = 1 - sum(W(obs_node,:));
    end
end
