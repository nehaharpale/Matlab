r = 1.6; %set communication range
num_nodes = 10; %Randomly generate nodes
n=2; %number of dimensions
%delta_t = 0.008; %0.008
delta_t_update = 0.008;%0.008; %for sine wave SN1
nodes = rand(num_nodes, n);
%Add measurement for each node: yi= theta + v_i
nodes_va = 50.*ones(num_nodes,1)+ 1*randn(num_nodes,1);
nodes_va0 = nodes_va; %save the initial measurement
nodes_va_old = nodes_va; %to update the consensus
[Nei_agent, A] = findneighbors(nodes,r,n);%delta_t_update);
figure(1), plot(nodes(:,1),nodes(:,2), 'm>','LineWidth',.2,'MarkerEdgeColor','m','MarkerFaceColor','m','MarkerSize',5)
hold on
for i = 1:num_nodes
%Line the neighbors together
tmp=nodes(Nei_agent{i},:);
for j = 1:size(nodes(Nei_agent{i},1))
line([nodes(i,1),tmp(j,1)],[nodes(i,2),tmp(j,2)],'Color','r','LineStyle','--');
% plot( [nodes(i,1) , tmp(j,1) ],[nodes(i,2),tmp(j,2)], 'b', 'LineWidth', 1 );
%     hold on
end
end
 

iteration = 80
Con = [];
for kk = 1: iteration
%===========Compute Metropolis weights==============
%Compute vertex and edge weights
end