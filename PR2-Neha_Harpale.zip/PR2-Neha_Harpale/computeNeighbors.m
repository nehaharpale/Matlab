function [sen_neighbors,degree] = computeNeighbors(Nodes,init_position,r)
    for node = Nodes
        neighbors = [];
        currNode = [init_position(node,1) init_position(node,2)];
        for neighbor = Nodes
            if node ~= neighbor
                currNeighbor = [init_position(neighbor,1) init_position(neighbor,2)];
                distance = norm(currNode - currNeighbor,2);
                if distance < r
                    neighbors(end+1)=neighbor;
                end
            end
        end
        sen_neighbors{node} = neighbors;
        degree(node) = size(neighbors,2);
    end
return