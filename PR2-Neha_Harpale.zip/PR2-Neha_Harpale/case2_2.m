clc,clear
close all
workspace;
flag=1;
if flag==1
    pos(1,:) = randperm(50,40);
    pos(2,:) = randperm(50,40);
    save('position.mat','pos');
else if flag==2
        load('position.mat','pos');
    end
end
cell_pos=[2,2];

cv=0.01;
x_pos=0+20*rand([50,1]);
y_pos= 0 + 20*rand([50,1]);
init_position= [x_pos,y_pos];
r=40;
[matrix,index] = neighbors(50,init_position,r);
nodes = nodes_cal(index);
rs=51;

Nodes = 1:50;
%ni=Nodes-1;
% noise 
% noise = 10;
% measure = 50 + randn(Nodes,1).*V;
ni=zeros(50,1); %%number of neighbors for each node
for j = Nodes
     ind1 = index(1,:)== j;           
     i1 = index(2,ind1);
     ni(j)=numel(i1);
   
end
%-Calculate neighbors of node--%
degree = zeros(50,1);
[sensor_neighbors,degree] = computeNeighbors(Nodes,init_position,r); 

 F=50;
 a = zeros(1,2);
  for j=Nodes
    a = sum (init_position); 
  end
 
qbar = (1/50) * [a];
nodes_va = 50.*ones(1,50)+ 1*randn(1,50);
nodes_va0 = nodes_va; %save the initial measurement
nodes_va_old = nodes_va; %to update the consensus

for i = Nodes %% this is wrong noise
    for j=Nodes
         V{i,j}= ([norm(init_position-a)^2]+cv) /[rs]^2;
         n{i,j}= [norm(0.0,V{i,j})];
         m{i,j}= F + n{i,j};
    end
end   %%% this is wrong noise
figure(1)
 draw_figure2(init_position,index);
% for j=1:Nodes
 %    for k=1:Nodes
 %      init_position = theta+V{i,j};
  %   end
 %end
 iterations = 1000;
 Con = [];
 n=50;
%  average weighted consensus - weight 1 %

 O=zeros(2,50);
 i2 = []; %%observable nodes
 for node = Nodes
            if norm(init_position(node,:)-cell_pos,2) <= rs
                O(1,node)=node;
                O(2,node)= 1;
            else
                O(1,node)=node;
            end
 end
 for j=Nodes
     if O(2,j) == 1
         i2(end+1) = O(1,j); %% matrix [i2]
     end
 end
%% i2=i2bar';
 W=[];
 [W] =computeMaximumdegreeWeight(i2,sensor_neighbors,n);
 [weight_matrix]=nodes_va0;

 %---------call for consensus--------%
 converged = false;
 s = 1;
        while ~converged && s < iterations
            s = s+1;
            % Find converged sensor weight
            [nodes_va_old,converged] = computeWeightConsensus(i2,nodes_va_old,W,sensor_neighbors);
            weight_matrix=[weight_matrix;nodes_va_old];
        end
 
 
 figure(2)
plot(Nodes,nodes_va_old,'-o',Nodes,nodes_va0,'-o');
hold on

 figure(3)
 for i=1:50
 plot(weight_matrix(:,i));
 xlim=([0 1000]);
 hold on;
 end

Weight=[];
[Weight] =computeMetropolisWeight(i2,sensor_neighbors);
[weight_matrix1]=nodes_va0;

 %---------call for consensus--------%
 converged = false;
 l = 1;
        while ~converged && l < iterations
            l = l+1;
            % Find converged sensor weight
            [nodes_va,converged] = computeWeightConsensus(i2,nodes_va,Weight,sensor_neighbors);
            weight_matrix1=[weight_matrix1;nodes_va];
        end
 
 figure(4)
plot(Nodes,nodes_va,'-o',Nodes,nodes_va0,'-o');
hold on

 figure(5)
 for i=1:50
 plot(weight_matrix1(:,i));
 xlim=([0 1000]);
 hold on;
 end
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 