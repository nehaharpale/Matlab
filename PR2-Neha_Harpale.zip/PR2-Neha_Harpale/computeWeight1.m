function [W]=computeWeight1(cv,rs,i2,sensor_neighbors,nodes_va)
     for obs_node = i2
        consider = intersect(i2,sensor_neighbors{obs_node});
        c1w = (2*cv / rs^2 * size(consider,2))/2 ;
        for j = consider
            W(obs_node,j) = c1w / (nodes_va(obs_node) + nodes_va(j));
        end
        W(obs_node,obs_node) = 1 - sum(W(obs_node,:));
     end
    end
    