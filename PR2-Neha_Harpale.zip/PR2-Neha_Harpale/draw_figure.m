
function draw_figure(position,index)

ii = sqrt(-1);
for k = 1 : max(size(index))
    i = index(1,k);
    j = index(2,k);    
    plot( [position(i,1) + ii*position(i,2), position(j,1) + ii*position(j,2)], 'b', 'LineWidth', 1 );
    hold on
end
plot(position(:,1) + position(:,2)*sqrt(-1),'o','Color','r','LineWidth',2,'MarkerSize',5)
hold on
plot(2,2,'m>','Color','c','LineWidth',2,'MarkerSize',5)
hold on
h = get(gcf,'CurrentAxes');
set(h, 'FontName', 'cmr10', 'FontSize', 18) 
drawnow;  
hold off

