

function E = incmat(idx,N)

% the number of nodes
if nargin == 2
    nv = N;
else
    nv = max(max(idx));
end

% the number of edges
ne = size(idx,2);

E = zeros(nv,ne);

for i = 1:ne
    E(idx(1,i),i) = 1;
    E(idx(2,i),i) = -1;
end
