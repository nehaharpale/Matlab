function nodes = nodes_cal(input)
    nodes=cell(10,2);    
    for i=1:10 
        nodes{i,1}=i;
        for k=1:length(input)
            if (input(1,k)==i)
                nodes{i,2}=[nodes{i,2},input(2,k)];
            end    
            if (input(2,k)==i)
                 nodes{i,2}=[nodes{i,2},input(1,k)];
            end
        end
    end
end    
            
                
