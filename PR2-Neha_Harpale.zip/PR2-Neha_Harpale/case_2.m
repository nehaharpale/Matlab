clc,clear
close all
workspace;
flag=1;
if flag==1
    pos(1,:) = randperm(30,25);
    pos(2,:) = randperm(30,25);
    save('position.mat','pos');
else if flag==2
        load('position.mat','pos');
    end
end

cv=0.01;
x_pos=0+25*rand([30,1]);
y_pos= 0 + 25*rand([30,1]);

init_position= [x_pos,y_pos];
r=30;
[matrix,index] = neighbors(30,init_position,r);
nodes = nodes_cal(index);
rs=27;

Nodes = 1:30;
ni=zeros(30,1); %%number of neighbors for each node
for j = Nodes
     ind1 = index(1,:)== j;           
     i1 = index(2,ind1);
     ni(j)=numel(i1);
end
%-Calculate neighbors of node--%
degree = zeros(30,1);
[sensor_neighbors,degree] = computeNeighbors(Nodes,init_position,r); 

n=30;
a = zeros(1,2);
  for j=Nodes
    a = sum (init_position); 
  end
 qbar = (1/n) * a;
 V=zeros(1,n);
 n1=zeros(1,n);
 Noise_num=30;
 

if exist('F1.mat','file')==2
    load('F1.mat');
end


ij=1:25;
ji=1:25;
F2=zeros(25,25);
m=zeros(1,30);

for ii=ij
    for jj=ji
        
 for k=1:n
     V(k)=((norm(init_position([k],:)-qbar)^2)+cv)/((rs)^2);
     n1(k)=V(k)*rand(1,1)+0;
     m(k)=F(ii,jj)+n1(k);
 end
  m0=m;
 
 iterations = 1000;
 Con = [];
 n=30;
 cell_pos=[ii,jj];
 O=zeros(2,30);
 i2 = []; %%observable nodes
 for node = Nodes 
            if norm(init_position(node,:)-cell_pos,2) <= rs
                O(1,node)=node; 
                O(2,node)= 1;
            else
                O(1,node)=node;
            end
 end
 for j=Nodes
     if O(2,j) == 1
         i2(end+1) = O(1,j); %% matrix [i2]
     end
 end
  L=0;
  W=[];
 [W] =computeWeight2(cv,rs,i2,sensor_neighbors,m0);
 %---------call for consensus--------%
 converged = false;
 l = 1;
 while ~converged && l < 2000
            l = l+1;
             converged = false;
    converged_weight = 0;
   
    for obs_node = i2
        m(obs_node) = m(obs_node) * W(obs_node,obs_node);
        for neighbor = intersect(sensor_neighbors{obs_node},i2)
            m(obs_node) = m(obs_node) + (W(obs_node,neighbor) * m(neighbor));
        end
    end
    
    mean_weight = mean(m(i2));
    
    if all(abs(m(i2)-mean_weight) < .01)
        converged_weight = mean_weight;
        converged = true;
        value=m(obs_node);
    end
 end
     indices = sub2ind(size(F2), ii, jj);
     F2(indices)=value;
    end
end
figure(1)
surf(-F);
figure(2)
surf(-F2);
err= F-F2 ;
figure(3)
surf(-err);
figure(4)
plot(err(:));
xlim([0 700])
ylim([-4 4])