function [W]=computeWeight2(cv,rs,i2,sensor_neighbors,nodes_va)
    for obs_node = i2
         W(obs_node,obs_node) = (((cv/(rs^2))-0)*rand(1,1))/nodes_va(obs_node);
        obs_neighbors = intersect(i2,sensor_neighbors{obs_node});
        for j = obs_neighbors
            W(obs_node,j) = (1-W(obs_node,obs_node))/(size(sensor_neighbors{obs_node},2));
        end
    end
end