function [nodes_va,converged] = computeWeightConsensus(i2,nodes_va,W,sensor_neighbors)

    converged = false;
    converged_weight = 0;
   
    for obs_node = i2
        nodes_va(obs_node) = nodes_va(obs_node) * W(obs_node,obs_node);
        for neighbor = intersect(sensor_neighbors{obs_node},i2)
            nodes_va(obs_node) = nodes_va(obs_node) + (W(obs_node,neighbor) * nodes_va(neighbor));
        end
    end
    
    mean_weight = mean(nodes_va(i2));
    
    if all(abs(nodes_va(i2)-mean_weight) < .01)
        converged_weight = mean_weight;
        converged = true;
        %value=nodes_va(obs_node);
    end
end