clc,clear
close all
workspace;
iter=35;
ku=1;
final=[];
while ku < iter
    ku=ku+1;
flag=1;
if flag==1
    pos(1,:) = randperm(10,8);
    pos(2,:) = randperm(10,8);
    save('position.mat','pos');
else if flag==2
        load('position.mat','pos');
    end
end
cell_pos=[2,2];
cv=0.01;
x_pos=0+4*rand([10,1]);
y_pos= 0 + 4*rand([10,1]);
init_position= [x_pos,y_pos];
r=5;
[matrix,index] = neighbors(10,init_position,r);
nodes = nodes_cal(index);
rs=3;

Nodes = 1:10;
%ni=Nodes-1;
% noise 
% noise = 10;
% measure = 50 + randn(Nodes,1).*V;
ni=zeros(10,1); %%number of neighbors for each node
for j = Nodes
     ind1 = index(1,:)== j;           
     i1 = index(2,ind1);
     ni(j)=numel(i1);
   
end
%-Calculate neighbors of node--%
degree = zeros(10,1);
[sensor_neighbors,degree] = computeNeighbors(Nodes,init_position,r); 

 F=50;
 a = zeros(1,2);
  for j=Nodes
    a = sum (init_position); 
  end
 
qbar = (1/10) * [a];
nodes_va = 50.*ones(1,10)+ 1*randn(1,10);
nodes_va0 = nodes_va; %save the initial measurement
nodes_va1 = nodes_va; %to update the consensus


figure(1)
 draw_figure(init_position,index);
 drawnow;
% for j=1:Nodes
 %    for k=1:Nodes
 %      init_position = theta+V{i,j};
  %   end
 %end
 Con = [];
 n=10;
%  average weighted consensus - weight 1 %

 O=zeros(2,10);
 i2 = []; %%observable nodes
 for node = Nodes
            if norm(init_position(node,:)-cell_pos,2) <= rs
                O(1,node)=node;
                O(2,node)= 1;
            else
                O(1,node)=node;
            end
 end
 for j=Nodes
     if O(2,j) == 1
         i2(end+1) = O(1,j); %% matrix [i2]
     end
 end

iterations=4;
W=[];
[W] =computeWeight2(cv,rs,i2,sensor_neighbors,nodes_va0);
weight_matrix1=[];
 %---------call for consensus--------%
 converged = false;
 l=1;
 
        while ~converged && l < iterations && ku ~= 34
            l = l+1;
            % Find converged sensor weight
            [nodes_va,converged] = computeWeightConsensus(i2,nodes_va,W,sensor_neighbors);
            weight_matrix1=[weight_matrix1;nodes_va];
        end
             final=[final;weight_matrix1];
             
        while ~converged && ku == 35 && l < 100
            l = l+1;
            % Find converged sensor weight
            [nodes_va,converged] = computeWeightConsensus(i2,nodes_va1,W,sensor_neighbors);
            weight_matrix1=[weight_matrix1;nodes_va];
        end
             final=[final;weight_matrix1];
  if ku==35
 figure(2)
plot(Nodes,nodes_va,'-o',Nodes,nodes_va1,'-o');
 grid on;
hold on
  end
figure(3) %%do changes to this figure
 for i=1:10
 plot(final(:,i));
 xlim([0 230])
 %ylim([-60 10])
 hold on;
 end

end
 
 
 
 
 
 
 
 
 
 
 
 
 